<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

use App\Http\Controllers\UserController;
use Illuminate\Http\Request;

$app->get('/', function () use ($app) {
    return $app->version();
});

$app->get('/users', 'UserController@index');

$app->post('/register', function (Request $request){
	$this->validate($request, [
		'userEmail'		=> 'bail|required|min:6|max:20',
		'userPassword'	=> 'bail|required|min:6|max:100',
		'userFirstName'	=> 'bail|required|min:2|max:30',
		'userLastName'	=> 'bail|required|min:2|max:50',
		'userPhone'		=> 'bail|required|min:10|max:16',
	]);

	return UserController::store($request);
});

# User Login
$app->post('/login', function (Request $request){
	$this->validate($request, [
		'userEmail'		=> 'bail|required|min:6|max:20',
		'userPassword'	=> 'bail|required|min:6|max:20'
	]);

	return UserController::show($request);
});

# User Update
$app->post('/user/update', 'UserController@update');

# User Change Password
$app->put('user/changepassword', function (Request $request){
	$this->validate($request, [
		'oldPassword'		=>	'bail|required|min:6|max:20',
		'newPassword'		=>	'bail|required|min:6|max:20',
		'confirmPassword'	=>	'bail|required|min:6|max:20'
	]);
	$userController = new UserController($request);
	return $userController->changePassword($request);
});

$app->get('/payment/source/categories', 'PaymentSourceCategoryController@index');
$app->get('/payment/source/category/{id}', 'PaymentSourceCategoryController@show');
$app->get('/services', 'ServiceController@index');
$app->get('/service/categories', 'CategoryController@index');
$app->get('/service/category/{id}', 'CategoryController@show');
$app->get('/service/providers', 'ServicesProviderController@index');
$app->get('/service/provider/{id}', 'ServicesProviderController@show');
$app->get('/transaction/{history}', 'TransactionController@handle');
$app->post('/transaction/{action}', 'TransactionController@handle');
