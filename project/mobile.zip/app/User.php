<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Auth\Authenticatable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class User extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
    	'userKey',
        'userFirstName',
		'userLastName',
		'userPhone',
		'userPassword',
		'userPin',
		'userEmail'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'userPassword',
		'userID'
    ];

    protected $table = 'tlr_users';
    protected $primaryKey = 'userKey';
    public $incrementing = false;

    const CREATED_AT = 'dateCreated';
    const UPDATED_AT = null;

	public static function store( $user )
	{
		$user['userFirstName']	= ucwords(strtolower($user['userFirstName']));
		$user['userLastName']	= ucwords(strtolower($user['userLastName']));
		$user['userPassword'] 	= User::passwordHash($user['userPassword']);
		$user['userPhone']		= User::getUserPhone($user['userPhone']);
		$user['userKey']		= User::getUserKey();
		$user['pin']			= '0000';
		return [User::create($user)[0]];
    }

	private static function getUserPhone( $phone )
	{
		$country = Country::where('countryNicename', ucwords(strtolower('ghana')))->first();
		return '+'.$country->countryPhoneCode.substr($phone, 1);
    }

	private static function passwordHash( $password )
	{
		return password_hash($password, PASSWORD_BCRYPT);
    }

	private static function getUserKey()
	{
		$str = '1QAZXSW23EDCVFR45TGBNHY67UJMKI89OLP0poiuytrewqasdfghjklmnbvcxz';
		return substr(str_shuffle($str),5, 15);
    }

	public static function login( Request $request )
	{
		$user = User::where('userEmail', $request->userEmail)->first();

		if (!password_verify($request->userPassword, $user->userPassword)){
			return [
				'code' => 900,
				'description' => 'Log in failed, please try again later'
			];
		}

		$user->userLastLogin 	= Carbon::now();
		$user->userLoginCount 	= $user->userLoginCount + 1;
		$user->save();
		return $user;
    }

	public static function isLoggedIn($request)
	{
		if($request->hasHeader('User-Token') && $request->header('User-Token') <> null){
			return User::where('userKey', $request->header('User-Token'))->first();
		}
		return response(['code' => 900, 'description' => 'Sorry, you\'ll have to be logged in to perform this task'],403);
    }
}
