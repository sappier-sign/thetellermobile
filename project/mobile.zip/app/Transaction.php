<?php
/**
 * Created by PhpStorm.
 * User: MEST
 * Date: 5/10/2017
 * Time: 2:02 PM
 */

namespace App;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
	protected $table		= 'tlr_transactions';
	protected $primaryKey	= 'transactionKey';
	public $incrementing	= false;

	protected $hidden		= [
		'transactionExtraData'
	];

	protected $fillable 	= [
		'transactionKey',
		'userKey',
		'serviceKey',
		'providerKey',
		'transactionAmount',
		'trasactionCharge',
		'billingAmount',
		'paymentSourceKey',
		'transactionRRN',
		'transactionSRN',
		'transactionDesc',
		'transactionDate',
		'transactionTime',
		'transactionStatus',
		'transactionExtraData'
	];

	const CREATED_AT = null;
	const UPDATED_AT = null;

	function __construct()
	{
		ini_set('max_execution_time', 120);
	}

	public function services()
	{
		return $this->belongsToMany(Service::class, 'tlr_services', 'serviceKey');
	}

	public static function performTransaction( $data )
	{
		$momo = [
			'hkJjfRplinyqTSM',
			'eVbK8jYX244dUsY',
			'dlBmL22jz5U843O',
			'hPQoQpio3Q6GbYe'
		];

		$cards = [
			'cuI6w81aBKse1JK',
			'dzbZ9nl3P59qtgM'
		];

		if ($data['paymentSourceKey'] === 'hkJjfRplinyqTSM'){
			$mode = 'mtn';
		} elseif ($data['paymentSourceKey'] === 'hPQoQpio3Q6GbYe'){
			$mode = 'airtel';
		} elseif ($data['paymentSourceKey'] === 'eVbK8jYX244dUsY'){
			$mode = 'tigo';
		} elseif ($data['paymentSourceKey'] === 'dlBmL22jz5U843O'){
			$mode = 'vodafone';
		} elseif ($data['paymentSourceKey'] === 'cuI6w81aBKse1JK'){
			$mode = 'mastercard';
		} elseif ($data['paymentSourceKey'] === 'dzbZ9nl3P59qtgM'){
			$mode = 'visa';
		} elseif ($data['paymentSourceKey'] === 'bMZaixFri1TvqA6'){
			$mode = 'ghlink';
		}

		$number = $data['number'];
		unset($data['number']);

		$desc = $data['desc'];
		unset($data['desc']);
		$class = new Transaction();
		$class->transactionKey 		= $data['transactionKey'];
		$class->userKey 			= $data['userKey'];
		$class->serviceKey 			= $data['serviceKey'];
		$class->providerKey 		= $data['providerKey'];
		$class->transactionAmount 	= $data['transactionAmount'];
		$class->trasactionCharge 	= $data['transactionCharge'];
		$class->billingAmount 		= $data['billingAmount'];
		$class->paymentSourceKey 	= $data['paymentSourceKey'];
		$class->transactionRRN 		= $data['transactionRRN'];
		$class->transactionSRN 		= $data['transactionSRN'];
		$class->transactionDesc 	= $data['transactionDesc'];
		$class->transactionDate 	= $data['transactionDate'];
		$class->transactionTime 	= $data['transactionTime'];
		$class->transactionExtraData = $data['transactionExtraData'];
		$class->save();

		if ($data['serviceKey'] === 'eoODpCgB9bpusCu'){
			if (in_array($data['paymentSourceKey'], $cards)){
				$response = $class->transfer($mode, $number, $data['billingAmount'], $data['transactionKey'], $desc, $data['recipient'], $data['network'], $data['credit_amount'], $data['expMonth'], $data['expYear'], $data['cvv'], $data['pin'], $data['ref'], $data['
				url']);
			} else {
				$response = $class->transfer($mode, $number, $data['billingAmount'], $data['transactionKey'], $desc, $data['recipient'], $data['network'], $data['credit_amount']);
			}

		} else {

			if (in_array($data['paymentSourceKey'], $momo)){

				$response = $class->debit( $mode, $number, $data['billingAmount'], $data['transactionKey'], $desc);

			} elseif (in_array($data['paymentSourceKey'], $cards)){

				$response = $class->debit( $mode, $number, $data['billingAmount'], $data['transactionKey'], $desc, $data['expMonth'], $data['expYear'], $data['pin'], $data['cvv'], $data['
				url'], $data['ref']);
			}
		}

		if ($response['code'] === 100){
			$row = Transaction::where('transactionKey', $data['transactionKey'])->first();
			$row->transactionStatus = 1;
			$row->save();
		} elseif ($response['status'] === 'vbv required'){

		} else {

		}

		return $response;
	}

	private function transfer( $mode, $number, $amount, $id, $desc, $recipient, $network, $credit_amount, $expMonth = null, $expYear = null, $cvv = null, $pin = null, $ref = null, $url = null )
	{
		$request = [
			'action'	=>	'transfer',
			'mode'		=>	$mode,
			'amount'	=>	$amount,
			'number'	=>	$number,
			'id'		=> 	$id,
			'desc'		=> 	$desc,
			'recipient'	=>  $recipient,
			'network'	=>	$network,
			'credit_amount'	=>	$credit_amount,
			'expMonth'	=>	$expMonth,
			'expYear'	=>	$expYear,
			'cvv'		=>	$cvv,
			'pin'		=>	$pin,
			'ref'		=>	$ref,
			'url'		=>	$url
		];
		return $this->curlRequest(json_encode($request));
		
	}

	private function debit( $mode, $number, $amount, $id, $desc, $expMonth = null, $expYear = null, $pin = null, $cvv = null, $url = null, $ref = null )
	{
		$request = [
			'action'	=>	'debit',
			'mode'		=>	$mode,
			'amount'	=>	$amount,
			'number'	=>	$number,
			'id'		=> 	$id,
			'desc'		=> 	$desc,
			'expMonth'	=>	$expMonth,
			'expYear'	=>	$expYear,
			'cvv'		=>	$cvv,
			'pin'		=>	$pin,
			'ref'		=>	$ref,
			'url'		=>	$url
		];

		return $this->curlRequest(json_encode($request));
	}

	private function curlRequest( $data )
	{
		$headers = [
			'Content-Type: application/json',
			'Accept: application/json',
			'Authorization: Basic '.base64_encode('thetellermobile:MTQzNDM2Nzk0MXRoZXRlbGxlcm1vYmlsZVdlZC1NYXkgMTAtMjAxNw==')
		];

		$curl = curl_init('https://api.theteller.net/index.php');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

		return json_decode(curl_exec($curl), true);
	}

	public static function history($userKey)
	{
		return Transaction::where('userKey', $userKey)->get();
	}
}