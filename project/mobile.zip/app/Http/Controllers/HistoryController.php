<?php
/**
 * Created by PhpStorm.
 * User: MEST
 * Date: 4/29/2017
 * Time: 12:21 PM
 */

namespace App\Http\Controllers;


class HistoryController extends Controller
{
	function __construct()
	{
	}
}