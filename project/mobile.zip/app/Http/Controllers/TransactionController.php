<?php
namespace App\Http\Controllers;
use App\Service;
use App\Transaction;
use Illuminate\Http\Request;

/**
 * Created by PhpStorm.
 * User: MEST
 * Date: 5/10/2017
 * Time: 2:25 PM
 */
class TransactionController extends Controller
{
	public function handle( Request $request, $action )
	{
		if ($action === 'debit' || $action === 'transfer'){
			$transaction = $request->all();
			$serviceName = Service::find($request->input('serviceKey'))->first()->serviceName;
			$transaction['transactionDesc'] 	= $serviceName. ' => theTellerApp '. $request->header('Platform').' => '.$request->input('transactionSRN');
			$transaction['userKey'] 			= $request->header('User-Token');
			$transaction['transactionExtraData'] = $request->header('Platform');
			$transaction['transactionStatus'] = 0;
			$transaction['transactionDate'] = date('Y-m-d');
			$transaction['transactionTime'] = date('H:i:s');
			return Transaction::performTransaction($transaction);
		} elseif ($action === 'history'){
			return Transaction::history($request->header('User-Token'));
		}
	}
}