<?php
/**
 * Created by PhpStorm.
 * User: MEST
 * Date: 5/1/2017
 * Time: 1:02 PM
 */

namespace App\Http\Controllers;


use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
	protected $authUser = null;

	/**
	 * @return null
	 */
	public function getAuthUser()
	{
		return $this->authUser;
	}

	/**
	 * @param null $authUser
	 */
	public function setAuthUser( $authUser )
	{
		$this->authUser = $authUser;
	}


	function __construct(Request $request)
	{
		$user = User::isLoggedIn($request);
		if ($user){
			$this->setAuthUser($user);
		}
	}

	public function index()
	{
		return User::all();
	}

	public static function store(Request $request)
	{
		return User::store($request->all());
	}

	public static function show( Request $request )
	{
		return User::login($request);
	}

	public function update( Request $request )
	{
		$user = $this->getAuthUser();

		$user->userTitle 		= ucwords(strtolower($request->input('title', $user->userTitle)));
		$user->userFirstName 	= ucwords(strtolower($request->input('firstName', $user->userFirstName)));
		$user->userLastName 	= ucwords(strtolower($request->input('lastName', $user->userLastName)));
		$user->userPin	 		= $request->input('pin', $user->userPin);
		$user->userGender 		= ucwords(strtolower($request->input('gender', $user->userGender)));
		$user->userDOB			= $request->input('dob', $user->userDOB);
		$user->userRegion		= ucwords(strtolower($request->input('region', $user->userRegion)));
		$user->userCity			= ucwords(strtolower($request->input('city', $user->userCity)));
		$user->userResAddress	= $request->input('address', $user->userResAddress);
		$user->userStatus		= $request->input('status', $user->userStatus);

		if ($user->save()){
			return [
				'code' => 100,
				'description' => 'Update successful'
			];
		}
	}

	public function changePassword( $request )
	{
		if ($request->newPassword <> $request->confirmPassword){
			return [
				'code'	=>	900,
				'description'	=>	'Password mismatch.'
			];
		} else {
			$user = $this->getAuthUser();
			if (password_verify($request->input('oldPassword'), $user->userPassword)){
				if (password_verify($request->input('newPassword'), $user->userPassword)){
					return [
						'code'	=>	900,
						'description'	=>	'New password cannot be the same as the current password.'
					];
				} else {
					$user->userPassword = password_hash($request->input('newPassword'), PASSWORD_BCRYPT);
					if ($user->save()){
						return [
							'code'	=>	100,
							'description'	=>	'Password changed successfully.'
						];
					} else {
						return [
							'code'	=>	900,
							'description'	=>	'Password could not be change at this time, please try again later.'
						];
					}
				}
			}
		}
		return [
			'code'	=>	900,
			'description'	=>	'Old password is wrong'
		];
	}
}